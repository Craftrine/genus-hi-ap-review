"""Replot saved CSV values only. Does not measure fields or calculate new contours."""
from pathlib import Path
import shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd,numpy as np
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator
HERE=Path(__file__).resolve().parent
# Load only reusable plotting definitions, not the old plotting actions.
old=HERE.parent/'smoothed_results/redraw.py'
scope={'__file__':str(old)}
exec(old.read_text().split('fig,axs=plt.subplots(4,4')[0],scope)
F=HERE/'figures';F.mkdir(exist_ok=True)
def save(fig,name):
 for ext in ['pdf','png']:fig.savefig(F/(name+'.'+ext),dpi=180)
 shutil.copy2(F/(name+'.pdf'),HERE.parents[1]/'figures'/(name+'.pdf'));plt.close(fig)
plotregion=scope['plotregion'];legend=scope['legend'];four=scope['four'];eleven=scope['eleven'];areas=scope['areas']
fig,axs=plt.subplots(4,3,figsize=(7.03,6.3),sharex=True,sharey=True);fig.subplots_adjust(left=.12,right=.98,top=.92,bottom=.17,wspace=.12,hspace=.13)
for j,(branch,title) in enumerate(zip(['nofg','horizontal_only','horizontal_m5'],['noFG','Horizontal cut',r'H + $m=1.692$'])):
 for i,mode in enumerate(['z2-z1','z3-z1','z4-z1','joint']):
  ax=axs[i,j];plotregion(ax,four[(four.branch==branch)&(four['mode']==mode)]);ax.set(xlim=(.19,.435),ylim=(-1.34,-.66),xticks=[.2,.3,.4],yticks=[-1.2,-1,-.8])
  if i==0:ax.set_title(title,pad=8)
  if i==3:ax.set_xlabel(r'$\Omega_m$')
  if j==0:ax.set_ylabel((rf'$z_{i+2}-z_1$' if i<3 else 'Joint')+'\n'+r'$w$')
fig.legend(handles=legend(),loc='lower center',bbox_to_anchor=(.54,.008),ncol=3,frameon=False,fontsize=8.5)
save(fig,'fig__intrinsic_subtracted_contours__four_cases')
fig,axs=plt.subplots(1,3,figsize=(7.03,2.65),sharex=True,sharey=True);fig.subplots_adjust(left=.11,right=.985,bottom=.23,top=.86,wspace=.14)
for ax,t in zip(axs,[.683,.954,.997]):
 s=areas[np.isclose(areas.target,t)].sort_values('m');ax.plot(s.m,s.area_over_horizontal,color='#24638b',marker='o',ms=3.7,lw=1.1);ax.axhline(1,color='.3',ls=':',lw=1);ax.set(title=f'{100*t:.1f}% weight',xlabel=r'$m$',xlim=(.25,1.65),ylim=(.76,1.12),xticks=[.3,.7,1.1,1.6],yticks=[.8,.9,1,1.1]);ax.tick_params(top=True,right=True)
axs[0].set_ylabel(r'$A_f(m)/A_f({\rm H})$');save(fig,'fig__intrinsic_subtracted_contours__eleven_m_areas')
fig,axs=plt.subplots(1,3,figsize=(7.03,3.15),sharex=True,sharey=True);fig.subplots_adjust(left=.1,right=.985,top=.87,bottom=.37,wspace=.18)
ref=eleven[eleven.branch=='horizontal_only']
for ax,branch,m in zip(axs,['m01','m09','m11'],[.294,1.517,1.692]):
 plotregion(ax,eleven[eleven.branch==branch],ref);ax.set(xlim=(.27,.35),ylim=(-1.12,-.88),xticks=[.28,.31,.34],yticks=[-1.1,-1,-.9],title=rf'$m={m:.3f}$',xlabel=r'$\Omega_m$')
axs[0].set_ylabel(r'$w$');fig.legend(handles=legend(True),loc='lower center',bbox_to_anchor=(.54,.005),ncol=3,frameon=False,fontsize=8.5);save(fig,'fig__intrinsic_subtracted_contours__representative_smoothed')
# Compact evolution: original fixed-covariance error bars, all saved values retained.
p=pd.read_csv(HERE/'intrinsic_subtracted.csv',float_precision='round_trip')
colors=['#d47d26','#368c4c','#a33a40'];styles=['--','-.',':'];snapshots=[112,105,94]
fig,axs=plt.subplots(4,3,figsize=(7.03,5.95),sharex=True);fig.subplots_adjust(left=.13,right=.985,top=.88,bottom=.13,hspace=.32,wspace=.32)
for j,(br,title) in enumerate(zip(['nofg','horizontal_only','horizontal_m5'],['noFG','Horizontal cut',r'H + $m=1.692$'])):
 for i,(ci,key) in enumerate([(1,'delta_g'),(1,'p'),(2,'delta_g'),(2,'p')]):
  ax=axs[i,j];d=p[(p.cosmology_id==ci)&(p.branch==br)]
  for sn,col,ls in zip(snapshots,colors,styles):
   q=d[d.snapshot==sn].sort_values('nu_f');assert len(q)==41
   ax.plot(q.nu_f,q[key]*1e6,color=col,ls=ls,lw=1)
   ax.errorbar(q.nu_f,q[key]*1e6,yerr=q.sigma_contour_fixed*1e6,fmt='none',ecolor=col,elinewidth=.4,capsize=.7,alpha=.55)
  lim=max((d.delta_g.abs()+d.sigma_contour_fixed).max(),(d.p.abs()+d.sigma_contour_fixed).max())*1e6*1.12
  ax.set(xlim=(-2.55,2.55),ylim=(-lim,lim),xticks=[-2,0,2]);ax.yaxis.set_major_locator(MaxNLocator(3));ax.axhline(0,c='.7',lw=.5,zorder=0);ax.tick_params(top=True,right=True,labelsize=9)
  if i==0:ax.set_title(title,pad=10)
  if j==0:ax.set_ylabel(('B' if ci==1 else 'C')+'  '+(r'$\Delta g$' if key=='delta_g' else r'$p$'))
  if i==3:ax.set_xlabel(r'$\nu_f$')
fig.legend(handles=[Line2D([],[],color=c,ls=l,label=rf'$z={z:.3f}-z_1$') for c,l,z in zip(colors,styles,[.19095,.31970,.59339])],loc='lower center',ncol=3,frameon=False,bbox_to_anchor=(.54,.005))
save(fig,'fig__cosmo_redshift_evolution__compact')
# Correlation-only main panel; the full covariance figure stays in the supplement.
d=pd.read_csv(HERE/'correlation.csv',float_precision='round_trip');nu=np.linspace(-2.5,2.5,41)
fig,axs=plt.subplots(1,4,figsize=(7.03,1.9));fig.subplots_adjust(left=.09,right=.90,top=.73,bottom=.13,wspace=.14)
for j,(br,title) in enumerate(zip(['nofg','horizontal_only','horizontal_m1','horizontal_m5'],['noFG','Horizontal cut',r'H + $m=0.294$',r'H + $m=1.692$'])):
 a=np.zeros((123,123))
 for t in d[d.branch==br].itertuples():
  i=(t.pair_i-2)*41+np.argmin(abs(nu-t.nu_i));k=(t.pair_j-2)*41+np.argmin(abs(nu-t.nu_j));a[i,k]=t.correlation
 ax=axs[j];im=ax.imshow(a,origin='lower',cmap='RdBu_r',vmin=-1,vmax=1,interpolation='nearest',rasterized=True)
 for edge in [40.5,81.5]:ax.axvline(edge,c='.3',lw=.4);ax.axhline(edge,c='.3',lw=.4)
 ax.set(xticks=[20,61,102],xticklabels=['2','3','4'],yticks=[20,61,102],yticklabels=['2','3','4'],title=title);ax.tick_params(length=0,labelleft=j==0)
axs[0].set_ylabel('Correlation');box=axs[-1].get_position();cax=fig.add_axes([.92,box.y0,.015,box.height]);fig.colorbar(im,cax=cax,ticks=[-1,0,1]);save(fig,'fig__covmat__correlation')

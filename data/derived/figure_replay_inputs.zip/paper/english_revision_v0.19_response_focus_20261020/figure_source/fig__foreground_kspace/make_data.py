"""Analytic mask boundaries only; no simulation input or measurement."""
from pathlib import Path
import numpy as np,json
D=Path(__file__).resolve().parent
x=np.linspace(0,.4,801)
np.savetxt(D/'boundaries.csv',np.c_[x,np.full_like(x,.1),.294*x,1.692*x],delimiter=',',header='k_perp,k_parallel_cut,wedge_m0294,wedge_m1692',comments='',fmt='%.12g')
a=np.linspace(0,np.pi/2,501)
rows=[]
for w in [.1,.001]:
 radius=np.sqrt(-2*np.log(w))/20
 rows.extend(zip(np.full_like(a,w),radius*np.cos(a),radius*np.sin(a)))
np.savetxt(D/'smoothing_contours.csv',rows,delimiter=',',header='W_R,k_perp,k_parallel',comments='',fmt='%.12g')
(D/'settings.json').write_text(json.dumps({'R_hinvMpc':20,'kparallel_cut_hMpcinv':.1,'m':[.294,1.692],'display_domain':{'kperp':[0,.4],'abs_kparallel':[0,.25]},'type':'analytic explanatory schematic; not measured power','error_bars':'not applicable'},indent=2))

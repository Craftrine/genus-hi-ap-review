# fig__foreground_kspace

2026-10-16按专家意见新增的前景切割几何图。正文v0.17 Fig.1；加入正式图册为第九个稳定身份，旧八图保留。

boundaries.csv保存全部水平线和wedge线的绘图节点；smoothing_contours.csv保存Gaussian场振幅W_R=0.1与0.001的圆弧节点。make_data.py只生成解析边界，没有模拟输入；redraw.py完全读取CSV重画，无需科学测量。无误差条。单位k为h/Mpc，R为h^-1Mpc；Gaussian曲线是场振幅衰减而非功率衰减，也不是硬截止。

四面板为noFG、H、H+m=0.294、H+m=1.692，和本文实测图的四分支对应。未把颜色面积解读为三维模式体积或测得功率。

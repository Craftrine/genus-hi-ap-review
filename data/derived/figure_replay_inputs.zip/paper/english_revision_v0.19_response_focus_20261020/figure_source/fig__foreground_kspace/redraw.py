"""Redraw entirely from saved CSV boundaries; does not rerun science."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
D=Path(__file__).resolve().parent
b=np.genfromtxt(D/'boundaries.csv',delimiter=',',names=True);s=np.genfromtxt(D/'smoothing_contours.csv',delimiter=',',names=True)
plt.rcParams.update({'font.family':'DejaVu Serif','font.size':9,'axes.labelsize':10,'axes.titlesize':10,'xtick.labelsize':8,'ytick.labelsize':8,'pdf.fonttype':42})
f,axs=plt.subplots(1,4,figsize=(10.4,3.1),sharex=True,sharey=True)
x=b['k_perp'];h=b['k_parallel_cut']
for i,(ax,title) in enumerate(zip(axs,['(a) No foreground cut','(b) Horizontal cut',r'(c) H + $m=0.294$',r'(d) H + $m=1.692$'])):
 ax.set_facecolor('#dceaf4')
 if i:
  ax.fill_between(x,0,h,color='#b6bbc1',zorder=1)
  ax.plot(x,h,color='#323a40',lw=1.15)
 if i>=2:
  w=b['wedge_m0294' if i==2 else 'wedge_m1692'];ax.fill_between(x,h,np.maximum(h,w),facecolor='#f2c18d',edgecolor='#ba762d',hatch='////',linewidth=0,zorder=2)
  ax.plot(x,w,color='#b46c20',lw=1.15)
 for wr,ls in [(.1,'--'),(.001,':')]:
  c=s[np.isclose(s['W_R'],wr)];ax.plot(c['k_perp'],c['k_parallel'],ls=ls,color='#303f4d',lw=.9,zorder=3)
 ax.set(xlim=(0,.4),ylim=(0,.25),title=title,xticks=[0,.1,.2,.3,.4],yticks=[0,.05,.1,.15,.2,.25]);ax.tick_params(direction='in',top=True,right=True)
 ax.set_xticks([0,.1,.2,.3,.4],labels=['0.0','0.1','0.2','0.3','0.4' if i==3 else ''])
 if i in [0,1]:ax.text(.26,.205,'Retained',color='#214a6b',ha='center',fontsize=8)
 if i==2:ax.text(.18,.205,'Retained',color='#214a6b',ha='center',fontsize=8)
 if i==3:ax.text(.06,.215,'Retained',color='#214a6b',ha='center',fontsize=8)
for ax in axs[:-1]: ax.get_xticklabels()[-1].set_visible(False)
f.supxlabel(r'$k_\perp\ [h\,\mathrm{Mpc}^{-1}]$',y=.17)
f.supylabel(r'$|k_\parallel|\ [h\,\mathrm{Mpc}^{-1}]$',x=.018)
f.legend(handles=[Patch(facecolor='#dceaf4',label='Retained modes'),Patch(facecolor='#b6bbc1',label='Horizontal removal'),Patch(facecolor='#f2c18d',edgecolor='#ba762d',hatch='////',label='Additional wedge removal'),Line2D([],[],color='#303f4d',ls='--',label=r'$W_R=0.1$'),Line2D([],[],color='#303f4d',ls=':',label=r'$W_R=10^{-3}$')],loc='lower center',ncol=5,frameon=False,bbox_to_anchor=(.52,.015),fontsize=8,columnspacing=1.3)
f.subplots_adjust(left=.085,right=.982,top=.88,bottom=.34,wspace=.08)
for ext in ['pdf','png']:f.savefig(D/f'fig__foreground_kspace.{ext}',dpi=200)

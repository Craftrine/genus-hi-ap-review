"""Redraw from saved contour vertices and areas; no parameter surface calculation."""
from pathlib import Path
import json
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path as MP
from matplotlib.patches import PathPatch,Patch
from matplotlib.lines import Line2D
from matplotlib.ticker import FuncFormatter,Formatter
O=Path(__file__).resolve().parent;T=O/'tables';F=O/'figures';F.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Serif','mathtext.fontset':'dejavuserif','font.size':10,'axes.labelsize':11,'axes.titlesize':10,'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,'axes.linewidth':.65,'pdf.fonttype':42,'xtick.direction':'in','ytick.direction':'in'})
C=['#24638b','#c76b20','#78448f'];LS=['-','--',':'];TARGETS=[.683,.954,.997];W=7.03
four=pd.read_csv(T/'four_cases_smoothed_vertices.csv',float_precision='round_trip');eleven=pd.read_csv(T/'eleven_smoothed_vertices.csv',float_precision='round_trip');areas=pd.read_csv(T/'area_trend_display.csv',float_precision='round_trip');hull=pd.read_csv(T/'publication_hull.csv')[['omega_m','w']].to_numpy();hull=np.vstack([hull,hull[0]])
def path(ax,d,color,ls='-',fill=False,lw=1.05):
 for _,s in d.groupby('component',sort=False):
  ax.add_patch(PathPatch(MP(s[['omega_m','w']].to_numpy(),s.code.to_numpy(np.uint8)),facecolor=color if fill else 'none',edgecolor='none' if fill else color,alpha=.20 if fill else 1,linestyle=ls,linewidth=lw,zorder=1 if fill else 4))
def plotregion(ax,d,ref=None):
 path(ax,d[d.kind=='fill'],C[0],fill=True)
 for t,c,ls in zip(TARGETS,C,LS):path(ax,d[(d.kind=='line')&np.isclose(d.target,t)],c,ls)
 if ref is not None:path(ax,ref[(ref.kind=='line')&np.isclose(ref.target,.683)],'#333333','-.',lw=1.1)
 ax.plot(hull[:,0],hull[:,1],color='.55',ls=(0,(5,3)),lw=.75,zorder=2)
 ax.plot(.3111,-1,marker='*',ms=6,mfc='#d7a63b',mec='#303030',mew=.55,zorder=8)
 ax.tick_params(top=True,right=True,length=2.5,pad=3)
 ax.xaxis.set_major_formatter(FuncFormatter(lambda v,pos:Formatter.fix_minus(f'{v:.2f}')))
def legend(ref=False):
 h=[Line2D([],[],color=c,ls=ls,label=f'{t*100:.1f}% weight') for t,c,ls in zip(TARGETS,C,LS)]
 h += [Patch(facecolor=C[0],alpha=.2,label='68.3% interior')]
 if ref:h += [Line2D([],[],color='#333333',ls='-.',lw=1.1,label='Horizontal cut (68.3%)')]
 h += [Line2D([],[],color='.55',ls=(0,(5,3)),lw=.75,label='Scan boundary'),Line2D([],[],color='none',marker='*',mfc='#d7a63b',mec='#303030',markersize=7,label='Simulation cosmology')]
 return h
metadata=[]
def save(fig,name):
 for ext in ['pdf','png']:fig.savefig(F/(name+'.'+ext),dpi=230)
 metadata.append({'name':name,'size_in':list(fig.get_size_inches()),'source':'saved CSV vertices and areas','single_smoothed_weight_method':True});plt.close(fig)
fig,axs=plt.subplots(4,4,figsize=(W,7.6),sharex=True,sharey=True);fig.subplots_adjust(left=.12,right=.985,top=.93,bottom=.16,wspace=.14,hspace=.13)
branches=['nofg','horizontal_only','horizontal_m1','horizontal_m5'];titles=['noFG','Horizontal cut',r'H + $m=0.294$',r'H + $m=1.692$'];modes=['z2-z1','z3-z1','z4-z1','joint']
for j,(b,title) in enumerate(zip(branches,titles)):
 for i,mode in enumerate(modes):
  ax=axs[i,j];plotregion(ax,four[(four.branch==b)&(four['mode']==mode)]);ax.set(xlim=(.19,.435),ylim=(-1.34,-.66),xticks=[.2,.3,.4],yticks=[-1.2,-1,-.8])
  if i==0:ax.set_title(title.replace('H +','H +\n'),pad=9)
  if i==3:ax.set_xlabel(r'$\Omega_m$')
  if j==0:ax.set_ylabel((r'$z_'+str(i+2)+r'-z_1$' if i<3 else 'Joint')+'\n'+r'$w$')
fig.legend(handles=legend(),loc='lower center',bbox_to_anchor=(.54,.018),ncol=3,frameon=False,columnspacing=1.1,handlelength=2.0)
save(fig,'fig__intrinsic_subtracted_contours__four_cases')
fig,axs=plt.subplots(3,4,figsize=(W,6.8),sharex=True,sharey=True);fig.subplots_adjust(left=.09,right=.985,top=.94,bottom=.225,wspace=.15,hspace=.30)
bm=pd.read_csv(T/'branch_map.csv');bm=bm[bm.branch.str.startswith('m')].sort_values('m');ref=eleven[eleven.branch=='horizontal_only']
for k,r in enumerate(bm.itertuples()):
 ax=axs.flat[k];plotregion(ax,eleven[eleven.branch==r.branch],ref);ax.set(xlim=(.27,.35),ylim=(-1.12,-.88),xticks=[.28,.31,.34],yticks=[-1.1,-1,-.9]);ax.set_title(rf'$m={r.m:.3f}$',pad=7)
 if k%4==0:ax.set_ylabel(r'$w$')
 if k>=8:ax.set_xlabel(r'$\Omega_m$')
axs.flat[-1].axis('off');fig.legend(handles=legend(True),loc='lower center',bbox_to_anchor=(.54,.012),ncol=3,frameon=False,columnspacing=.9,handlelength=2.1,labelspacing=.7)
save(fig,'fig__intrinsic_subtracted_contours__eleven_m_smoothed')
fig,axs=plt.subplots(1,3,figsize=(W,2.95),sharex=True,sharey=True);fig.subplots_adjust(left=.12,right=.985,bottom=.30,top=.88,wspace=.16)
for ax,t in zip(axs,TARGETS):
 s=areas[np.isclose(areas.target,t)].sort_values('m');ax.plot(s.m,s.area_over_horizontal,color=C[0],marker='o',ms=3.7,lw=1.1);ax.axhline(1,color='.3',ls=':',lw=1);ax.set(title=f'{t*100:.1f}% weight',xlabel=r'$m$',xlim=(.25,1.65),ylim=(.76,1.12),xticks=[.3,.7,1.1,1.6],yticks=[.8,.9,1.,1.1]);ax.tick_params(top=True,right=True,pad=3)
axs[0].set_ylabel(r'$A_f(m)/A_f({\rm H})$');fig.text(.54,.05,'Dotted line: horizontal-cut reference',ha='center',fontsize=9)
save(fig,'fig__intrinsic_subtracted_contours__eleven_m_areas')
(O/'FIGURE_MANIFEST.json').write_text(json.dumps(metadata,indent=2))

"""Publication figures from archived text data only. No field/FFT/genus measurement.
Run with Python + NumPy/Pandas/Matplotlib. Geometry comes from accepted contour
vertices and canonical triangle indices; this replay does not reintegrate areas.
"""
from pathlib import Path
import argparse,json
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path as MP
from matplotlib.patches import PathPatch
from matplotlib.lines import Line2D
from matplotlib.colors import SymLogNorm
from matplotlib.ticker import MaxNLocator,FuncFormatter,Formatter
from matplotlib.backends.backend_pdf import PdfPages
O=Path(__file__).resolve().parent;OUT=O/'figures';OUT.mkdir(exist_ok=True)
W=7.029;S=3.376
plt.rcParams.update({'axes.unicode_minus':True,'font.family':'DejaVu Serif','mathtext.fontset':'dejavuserif','font.size':10,'axes.labelsize':11,'axes.titlesize':10,'xtick.labelsize':10,'ytick.labelsize':10,'legend.fontsize':10,'axes.linewidth':.6,'lines.linewidth':1.2,'pdf.fonttype':42,'ps.fonttype':42,'savefig.dpi':240,'xtick.direction':'in','ytick.direction':'in'})
BR=['nofg','horizontal_only','horizontal_m1','horizontal_m5'];SN=[118,112,105,94]
TIT=['noFG','Horizontal cut',r'Horizontal + $m=0.294$',r'Horizontal + $m=1.692$']
SHORT=['noFG','Horizontal cut',r'H + $m=0.294$',r'H + $m=1.692$']
COL=['#202020','#287ca3','#ce7625','#9b4574'];LS=['-','--','-.',':']
PC=['#24638b','#c76b20','#78448f'];PLS=['-','--',':'];TARGETS=[.683,.954,.997]
metadata=[]
def read(n):return pd.read_csv(O/'tables'/n,float_precision='round_trip')
def source(n,f='data.csv'):return pd.read_csv(O/'source_data'/n/f,float_precision='round_trip')
def clean(ax,zero=False):
 ax.tick_params(pad=3,length=3);ax.spines[:].set_visible(True)
 if zero:ax.axhline(0,color='.65',lw=.5,zorder=0)
 ax.xaxis.set_major_locator(MaxNLocator(3));ax.yaxis.set_major_locator(MaxNLocator(4))
def save(fig,name,page=None):
 filename=name+(f'__{page}' if page else '')
 fig.savefig(OUT/(filename+'.pdf'));fig.savefig(OUT/(filename+'.png'),dpi=240)
 metadata.append(dict(name=filename,width_in=fig.get_figwidth(),height_in=fig.get_figheight(),min_base_font_pt=10))
 # Collect page-boundary text overflows for QA; panel overlap is visually checked.
 fig.canvas.draw();renderer=fig.canvas.get_renderer();bb=fig.bbox
 violations=[]; hidden_tick_labels=set()
 for ax in fig.axes:
  for axis,lims in [(ax.xaxis,ax.get_xlim()),(ax.yaxis,ax.get_ylim())]:
   for tick in axis.get_major_ticks():
    if not min(lims)<=tick.get_loc()<=max(lims):hidden_tick_labels.update([id(tick.label1),id(tick.label2)])
 for text in fig.findobj(matplotlib.text.Text):
  if not text.get_visible() or not text.get_text() or id(text) in hidden_tick_labels:continue
  b=text.get_window_extent(renderer)
  if b.x0 < -.5 or b.y0 < -.5 or b.x1>bb.x1+.5 or b.y1>bb.y1+.5:violations.append(text.get_text())
 metadata[-1]['off_canvas_text']=violations
 intrusions=[]
 for ax in fig.axes:
  for tick in ax.yaxis.get_major_ticks():
   t=tick.label1
   if not t.get_visible() or not min(ax.get_ylim())<=tick.get_loc()<=max(ax.get_ylim()):continue
   tb=t.get_window_extent(renderer)
   for other in fig.axes:
    if other is ax:continue
    ob=other.get_window_extent(renderer)
    if tb.overlaps(ob):intrusions.append(t.get_text())
 metadata[-1]['yticks_over_other_axes']=intrusions

def foreground():
 name='fig__noFG_hcut_msan_comp';d=source(name);fig,ax=plt.subplots(figsize=(S,3.8));fig.subplots_adjust(left=.20,right=.98,bottom=.37,top=.98)
 colors=['#171717','#93b7c4','#bba77a','#773a5c'];styles=['-','--','-.',':'];widths=[1.4,2.8,2.1,1.8]
 for j,b in enumerate(BR):
  s=d[d.branch==b];ax.plot(s.nu_f,s.g_h3_Mpc3*1e6,c=colors[j],ls=styles[j],lw=widths[j],label=TIT[j],zorder=5 if j==2 else 3)
  ax.errorbar(s.nu_f,s.g_h3_Mpc3*1e6,yerr=s.sigma_g_64*1e6,fmt='none',ecolor=colors[j],elinewidth=.5,capsize=1.1,alpha=.7)
 clean(ax,True);ax.set(xlim=(-2.55,2.55),xlabel=r'$\nu_f$',ylabel=r'$g\ [10^{-6}\,h^3\,\mathrm{Mpc}^{-3}]$');ax.set_xticks([-2,0,2])
 h,l=ax.get_legend_handles_labels();fig.legend(h,l,loc='lower center',bbox_to_anchor=(.52,.006),frameon=False,ncol=1,handlelength=2.7,labelspacing=.45)
 save(fig,name);plt.close(fig)

def redshifts():
 name='fig__diff_redshifts';d=source(name);dd=source(name,'differences.csv')
 fig,ax=plt.subplots(2,4,figsize=(W,4.25),sharex='col',gridspec_kw={'height_ratios':[2,1],'hspace':.16})
 fig.subplots_adjust(left=.12,right=.99,bottom=.23,top=.88,wspace=.78)
 handles=None
 for bi,b in enumerate(BR):
  for j,snap in enumerate(SN):
   s=d[(d.branch==b)&(d.snapshot==snap)];ax[0,bi].plot(s.nu_f,s.g_h3_Mpc3*1e6,c=COL[j],ls=LS[j],lw=1.25,label=rf'$z={s.z.iloc[0]:.3f}$')
   ax[0,bi].errorbar(s.nu_f,s.g_h3_Mpc3*1e6,yerr=s.sigma_g_64*1e6,fmt='none',ecolor=COL[j],alpha=.5,elinewidth=.45,capsize=.8)
   if j:
    s=dd[(dd.branch==b)&(dd.snapshot==snap)];ax[1,bi].plot(s.nu_f,s.delta_g*1e6,c=COL[j],ls=LS[j]);ax[1,bi].errorbar(s.nu_f,s.delta_g*1e6,yerr=s.sigma_delta_g_64*1e6,fmt='none',ecolor=COL[j],elinewidth=.45,capsize=.8,alpha=.6)
  ax[0,bi].set_title(f'({chr(97+bi)}) '+SHORT[bi].replace('H +','H +\n'),pad=9)
  for a in ax[:,bi]:clean(a,True);a.set_xlim(-2.55,2.55);a.set_xticks([-2,0,2])
  ax[1,bi].set_xlabel(r'$\nu_f$')
 ax[0,0].set_ylabel(r'$g$');ax[1,0].set_ylabel(r'$g(z)-g(z_1)$');ax[0,0].yaxis.set_label_coords(-.48,.5);ax[1,0].yaxis.set_label_coords(-.48,.5)
 h,l=ax[0,0].get_legend_handles_labels();fig.legend(h,l,loc='lower center',bbox_to_anchor=(.53,.005),ncol=4,frameon=False,columnspacing=1,handlelength=2)
 save(fig,name);plt.close(fig)

def cosmologies():
 name='fig__diff_cosmo';d=source(name)
 fig,ax=plt.subplots(2,4,figsize=(W,4.1),sharex='col',gridspec_kw={'height_ratios':[2,1],'hspace':.17});fig.subplots_adjust(left=.12,right=.99,bottom=.28,top=.90,wspace=.78)
 pars=[(.3111,-1),(.2,-1.4),(.42,-.6)]
 for bi,b in enumerate(BR):
  for j,(om,w) in enumerate(pars):
   s=d[(d.branch==b)&np.isclose(d.omega_m_scan,om)&np.isclose(d.w_scan,w)]
   label=('sim' if j==0 else f'scan {j}')+rf': $(\Omega_m,w)=({om:g},{w:g})$'
   ax[0,bi].plot(s.nu_f,s.g*1e6,c=COL[j],ls=LS[j],label=label);ax[0,bi].errorbar(s.nu_f,s.g*1e6,yerr=s.sigma_g_64*1e6,fmt='none',ecolor=COL[j],elinewidth=.45,capsize=.8,alpha=.5)
   if j:ax[1,bi].plot(s.nu_f,s.difference_from_sim*1e6,c=COL[j],ls=LS[j])
  ax[0,bi].set_title(f'({chr(97+bi)}) '+SHORT[bi].replace('H +','H +\n'),pad=9)
  for a in ax[:,bi]:clean(a,True);a.set_xlim(-2.55,2.55);a.set_xticks([-2,0,2])
  ax[1,bi].set_xlabel(r'$\nu_f$')
 ax[0,0].set_ylabel(r'$g$');ax[1,0].set_ylabel(r'$g_{\rm scan}-g_{\rm sim}$');ax[0,0].yaxis.set_label_coords(-.48,.5);ax[1,0].yaxis.set_label_coords(-.48,.5)
 h,l=ax[0,0].get_legend_handles_labels();fig.legend(h,l,loc='lower center',bbox_to_anchor=(.53,.003),ncol=1,frameon=False,labelspacing=.35)
 save(fig,name);plt.close(fig)

def slices():
 name='fig__slices';folder=O/'source_data'/name;m=json.loads((folder/'metadata.json').read_text());fig=plt.figure(figsize=(W,8.6))
 xs=[.100,.326,.552,.778];width=.204;height=width*W/8.6;ys=[.72,.525,.285,.09];coord=np.arange(250)*4+2
 for row,(plane,snap) in enumerate([('xz',118),('xz',94),('xy',118),('xy',94)]):
  for col,b in enumerate(BR):
   v=next(v for v in m['slices'] if v['plane']==plane and v['snapshot']==snap and v['branch']==b);a=np.loadtxt(folder/v['file'],delimiter=',');sig=v['sigma_full3D']
   ax=fig.add_axes([xs[col],ys[row],width,height]);im=ax.imshow(a.T/sig,origin='lower',extent=(0,1000,0,1000),cmap='RdBu_r',vmin=-3,vmax=3,interpolation='nearest',rasterized=True)
   ax.contour(coord,coord,a.T,levels=[v['median_threshold_full3D']],colors='#293640',linewidths=.24,linestyles='solid',alpha=.65)
   ax.set_xticks([0,500,1000]);ax.set_yticks([0,500,1000]);ax.tick_params(labelbottom=row in [1,3],labelleft=col==0,pad=3,length=2)
   # Endpoint labels align inward so adjacent 1000 / 0 cannot collide.
   ts=ax.xaxis.get_major_ticks();ts[0].label1.set_ha('left');ts[-1].label1.set_ha('right')
   if col==0:ax.set_ylabel(r'$z_{\rm LOS}$' if plane=='xz' else r'$y$')
   ax.text(.025,.965,f'({chr(97+row*4+col)})',transform=ax.transAxes,va='top',fontsize=10,bbox=dict(facecolor='white',alpha=.8,edgecolor='none',pad=.5))
   ax.text(.97,.035,rf'$\sigma={sig:.4f}$',transform=ax.transAxes,ha='right',fontsize=10,bbox=dict(facecolor='white',alpha=.85,edgecolor='none',pad=1))
  fig.text(.54,ys[row]+height+.012,rf'$z={v["z"]:.3f}$',ha='center',fontsize=10)
 for x,t in zip(xs,SHORT):fig.text(x+width/2,.949,t.replace('H +','H +\n'),ha='center',va='center',fontsize=10)
 fig.text(.10,.986,'A  Line-of-sight slices',va='top',fontsize=11)
 fig.text(.10,.488,'B  Transverse slices',va='top',fontsize=11)
 # One shared x label at bottom avoids the B-heading/redshift collision.
 fig.text(.54,.043,r'$x\ [h^{-1}\,\mathrm{Mpc}]$',ha='center',fontsize=11)
 # Compact shared colour scale; units moved to caption.
 cax=fig.add_axes([.24,.009,.59,.011]);cb=fig.colorbar(im,cax=cax,orientation='horizontal',ticks=[-3,-2,-1,0,1,2,3],extend='both');cb.ax.xaxis.set_ticks_position('top');cb.ax.tick_params(pad=1,length=2)
 save(fig,name);plt.close(fig)

def covariance():
 name='fig__covmat';d=source(name,'covariance.csv');C=np.zeros((4,123,123));nu=np.linspace(-2.5,2.5,41)
 for r in d.itertuples():
  i=(r.pair_i-2)*41+np.argmin(abs(nu-r.nu_i));j=(r.pair_j-2)*41+np.argmin(abs(nu-r.nu_j));C[BR.index(r.branch),i,j]=r.covariance
 sd=np.sqrt(np.diagonal(C,axis1=1,axis2=2));corr=C/sd[:,:,None]/sd[:,None,:];lim=abs(C*1e15).max()
 fig,ax=plt.subplots(2,4,figsize=(W,3.85));fig.subplots_adjust(left=.10,right=.89,bottom=.12,top=.87,wspace=.12,hspace=.48)
 for bi in range(4):
  for row in range(2):
   a=ax[row,bi];im=a.imshow(C[bi]*1e15 if row==0 else corr[bi],origin='lower',cmap='RdBu_r',interpolation='nearest',rasterized=True,norm=SymLogNorm(linthresh=lim/1000,vmin=-lim,vmax=lim) if row==0 else matplotlib.colors.Normalize(-1,1))
   for edge in [40.5,81.5]:a.axvline(edge,c='.3',lw=.4);a.axhline(edge,c='.3',lw=.4)
   a.set_xticks([20,61,102],[r'$2$',r'$3$',r'$4$']);a.set_yticks([20,61,102],[r'$2$',r'$3$',r'$4$']);a.tick_params(length=0,labelleft=bi==0)
   if bi==0:a.set_ylabel('Covariance' if row==0 else 'Correlation')
   if row==0:a.set_title(SHORT[bi].replace('H +','H +\n'),pad=10)
  if bi==3:
   for row in range(2):
    box=ax[row,bi].get_position();cax=fig.add_axes([.91,box.y0,.018,box.height]);mappable=ax[row,bi].images[0]
    cb=fig.colorbar(mappable,cax=cax,ticks=[-lim,0,lim] if row==0 else [-1,0,1]);cb.ax.tick_params(labelsize=10,length=2)
    if row==0:cb.ax.set_yticklabels([Formatter.fix_minus(f'{-lim:.1f}'),'0',f'{lim:.1f}'])
 save(fig,name);plt.close(fig)

def evolution():
 name='fig__cosmo_redshift_evolution';d=source(name);dd=source(name,'differences.csv');pp=source(name,'intrinsic_subtracted.csv');qq=source(name,'chisq_annotations.csv')
 pars=[(.3111,-1),(.2,-1.4),(.42,-.6)];lims=[]
 for b in BR:
  a=d[d.branch==b];s=dd[(dd.branch==b)&(dd.snapshot!=118)];t=pp[pp.branch==b]
  lo=((a.g-a.sigma_g)*1e6).min();hi=((a.g+a.sigma_g)*1e6).max();dl=max(((s.delta_g.abs()+s.sigma_delta_g)*1e6).max(),((t.p.abs()+t.sigma_contour_fixed)*1e6).max())
  lims.append(((lo-.05*(hi-lo),hi+.08*(hi-lo)),(-1.15*dl,1.15*dl)))
 with PdfPages(OUT/(name+'.pdf')) as pdf:
  for ci,(om,w) in enumerate(pars):
   fig=plt.figure(figsize=(W,7.8));gs=fig.add_gridspec(3,4,left=.12,right=.99,bottom=.16,top=.78,hspace=.80,wspace=.78,height_ratios=[1.3,1,1])
   for bi,b in enumerate(BR):
    axes=[fig.add_subplot(gs[r,bi]) for r in range(3)]
    for j,snap in enumerate(SN):
     s=d[(d.cosmology_id==ci)&(d.branch==b)&(d.snapshot==snap)]
     axes[0].plot(s.nu_f,s.g*1e6,c=COL[j],ls=LS[j],label=rf'$z={s.redshift.iloc[0]:.3f}$');axes[0].errorbar(s.nu_f,s.g*1e6,yerr=s.sigma_g*1e6,fmt='none',ecolor=COL[j],elinewidth=.45,capsize=.7,alpha=.5)
     if j:
      a=dd[(dd.cosmology_id==ci)&(dd.branch==b)&(dd.snapshot==snap)];t=pp[(pp.cosmology_id==ci)&(pp.branch==b)&(pp.snapshot==snap)]
      for row,vals in [(1,a.delta_g),(2,t.p)]:
       axes[row].plot(t.nu_f,vals.to_numpy()*1e6,c=COL[j],ls=LS[j]);axes[row].errorbar(t.nu_f,vals.to_numpy()*1e6,yerr=t.sigma_contour_fixed*1e6,fmt='none',ecolor=COL[j],elinewidth=.45,capsize=.7,alpha=.6)
    joint=qq[(qq.cosmology_id==ci)&(qq.branch==b)&(qq.snapshot=='joint')].iloc[0]
    a=axes[0];box=a.get_position();center=(box.x0+box.x1)/2
    fig.text(center,.914,SHORT[bi].replace('H +','H +\n'),ha='center',va='center',fontsize=10)
    fig.text(min(center,.90),.86,'Joint: '+rf'$\chi^2={joint.chi2_before_intrinsic:.1f}$'+'\n'+rf'$\chi^2_{{\rm int}}={joint.chi2_after_intrinsic:.1f}$',ha='center',va='center',fontsize=10,linespacing=1.55)
    for row,key,label in [(1,'chi2_before_intrinsic',r'$\chi^2$'),(2,'chi2_after_intrinsic',r'$\chi^2_{\rm int}$')]:
     a=axes[row];a.text(.5,1.66,label,ha='center',transform=a.transAxes,fontsize=10)
     for j,snap in enumerate(SN[1:]):
      q=qq[(qq.cosmology_id==ci)&(qq.branch==b)&(qq.snapshot==str(snap))].iloc[0]
      a.text(.5,1.46-.18*j,f'{q[key]:.1f}',color=COL[j+1],ha='center',transform=a.transAxes,fontsize=10)
    for row,a in enumerate(axes):
     clean(a,True);a.set_xlim(-2.55,2.55);a.set_xticks([-2,0,2]);a.set_ylim(lims[bi][0 if row==0 else 1]);a.yaxis.set_major_locator(MaxNLocator(3,prune='both'));a.tick_params(labelbottom=row==2)
     if bi==0:a.set_ylabel([r'$g$',r'$\Delta g$',r'$p=\Delta g-I$'][row]);a.yaxis.set_label_coords(-.50,.5)
     if row==2:a.set_xlabel(r'$\nu_f$')
    if bi==0:handles,labels=axes[0].get_legend_handles_labels()
   fig.text(.085,.974,chr(65+ci)+('  sim' if ci==0 else f'  scan {ci}')+rf'   $(\Omega_m,w)=({om:g},{w:g})$',va='top',fontsize=11)
   fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.54,.022),ncol=2,frameon=False,columnspacing=1.5,handlelength=2.3)
   save(fig,name,chr(65+ci));pdf.savefig(fig);plt.close(fig)

CV=None

def contour_data():
 global CV
 if CV is None:CV=read('publication_contour_vertices.csv')
 return CV

def paths(ax,s,color,ls='-',lw=1,fill=False,alpha=1):
 for _,a in s.groupby('component',sort=False):
  p=MP(a[['omega_m','w']].to_numpy(),a.code.to_numpy(np.uint8))
  ax.add_patch(PathPatch(p,facecolor=color if fill else 'none',edgecolor='none' if fill else color,linewidth=lw,linestyle=ls,alpha=alpha,zorder=1 if fill else 3))

def select(family,b,mode='joint',variant='no_gaussian'):
 d=contour_data();return d[(d.family==family)&(d.branch==b)&(d['mode']==mode)&(d.variant==variant)]

def region(ax,s,reference=None,thin_reference=False):
 paths(ax,s[s.kind=='fill'],PC[0],fill=True,alpha=.20)
 for f,c,ls in zip(TARGETS,PC,PLS):paths(ax,s[(s.kind=='line')&np.isclose(s.target,f)],c,ls,1.1)
 if reference is not None:paths(ax,reference[(reference.kind=='line')&np.isclose(reference.target,.683)],'.50' if thin_reference else '.15','-.',.65 if thin_reference else 1.45)
 ax.plot(.3111,-1,marker='*',ms=6,mfc='#d3a037',mec='.2',mew=.65,zorder=8)
 clean(ax);ax.xaxis.set_major_formatter(FuncFormatter(lambda v,pos:Formatter.fix_minus(f'{v:.2f}')));ax.yaxis.set_major_formatter(FuncFormatter(lambda v,pos:Formatter.fix_minus(f'{v:.1f}')))

def region_legend(fig,loc=(.52,.015),reference=False):
 handles=[Line2D([0],[0],c=c,ls=ls,label=f'{f*100:.1f}%') for f,c,ls in zip(TARGETS,PC,PLS)]
 if reference:handles.append(Line2D([0],[0],c='.15',ls='-.',lw=1.45,label='Horizontal cut (68.3%)'))
 fig.legend(handles=handles,loc='lower center',bbox_to_anchor=loc,ncol=2 if reference else 3,frameon=False,handlelength=2.5,columnspacing=1.3)

def four_cases():
 fig,axs=plt.subplots(4,4,figsize=(W,7.7),sharex=True,sharey=True);fig.subplots_adjust(left=.12,right=.985,top=.92,bottom=.14,hspace=.16,wspace=.17)
 hull=read('publication_hull.csv')[['omega_m','w']].to_numpy();hull=np.vstack([hull,hull[0]])
 modes=['z2-z1','z3-z1','z4-z1','joint']
 # Full common scanned domain: do not crop open contours. Insets are not used.
 for j,b in enumerate(BR):
  all_s=pd.concat([select('four_cases',b,m) for m in modes]);lines=all_s[all_s.kind=='line']
  xl=(.19,.435);yl=(-1.34,-.66)
  for i,mode in enumerate(modes):
   ax=axs[i,j];region(ax,select('four_cases',b,mode));ax.plot(hull[:,0],hull[:,1],c='.6',ls='--',lw=.65,zorder=0);ax.set_xlim(xl);ax.set_ylim(yl);ax.set_xticks([.20,.30,.40]);ax.set_yticks([-1.2,-1.0,-.8])
   if i==0:ax.set_title(SHORT[j].replace('H +','H +\n'),pad=10)
   if j==0:ax.set_ylabel((r'$z_'+str(i+2)+r'-z_1$' if i<3 else 'Joint')+'\n'+r'$w$')
   if i==3:ax.set_xlabel(r'$\Omega_m$')
 region_legend(fig,(.54,.015));save(fig,'fig__intrinsic_subtracted_contours__four_cases');plt.close(fig)


def eleven_regions(variant):
 fig,axs=plt.subplots(3,4,figsize=(W,6.8),sharex=True,sharey=True);fig.subplots_adjust(left=.085,right=.99,bottom=.12,top=.95,hspace=.33,wspace=.20)
 bm=read('eleven_wedge_nodal_Q.csv')[['branch','m']].drop_duplicates();bm=bm[bm.branch.str.startswith('m')].sort_values('m');ref=select('eleven','horizontal_only',variant=variant)
 # Preserve the previous smoothed view; derive a separate tight raw view from saved paths.
 d=contour_data();all_s=d[(d.family=='eleven')&d.branch.str.startswith('m')&(d.kind=='line')]
 xl=(min(.27,all_s.omega_m.min()-.002),max(.35,all_s.omega_m.max()+.002));yl=(min(-1.12,all_s.w.min()-.007),max(-.88,all_s.w.max()+.007))
 if variant=='no_gaussian':
  fig.subplots_adjust(left=.12)
  raw=all_s[all_s.variant==variant]
  raw=pd.concat([raw,ref[(ref.kind=='line')&np.isclose(ref.target,.683)]])
  xl=(float(raw.omega_m.min())-.002,float(raw.omega_m.max())+.002)
  yl=(float(raw.w.min())-.005,float(raw.w.max())+.005)
 view=dict(variant=variant,xlim=xl,ylim=yl)
 (O/'qa'/f'eleven_view_{variant}.json').write_text(json.dumps(view,indent=2))
 for k,r in enumerate(bm.itertuples()):
  ax=axs.flat[k];region(ax,select('eleven',r.branch,variant=variant),ref,thin_reference=variant=='no_gaussian');ax.set(xlim=xl,ylim=yl);ax.set_title(rf'$m={r.m:.3f}$',pad=6);ax.set_xticks([.28,.31,.34]);ax.set_yticks([-1.1,-1.0,-.9])
  if variant=='no_gaussian':
   ax.set_xticks([.29,.31,.33]);ax.set_yticks([-1.05,-1.00,-.95]);ax.yaxis.set_major_formatter(FuncFormatter(lambda v,pos:Formatter.fix_minus(f'{v:.2f}')))
  if k%4==0:ax.set_ylabel(r'$w$')
  if k>=8:ax.set_xlabel(r'$\Omega_m$')
 
 hull=read('publication_hull.csv')[['omega_m','w']].to_numpy();hull=np.vstack([hull,hull[0]])
 for ax in list(axs.flat)[:-1]:ax.plot(hull[:,0],hull[:,1],c='.65',ls='--',lw=.6,zorder=0)
 axs.flat[-1].axis('off')
 handles=[Line2D([0],[0],c=c,ls=ls,label=f'{f*100:.1f}%') for f,c,ls in zip(TARGETS,PC,PLS)]+[Line2D([0],[0],c='.50' if variant=='no_gaussian' else '.15',ls='-.',lw=.65 if variant=='no_gaussian' else 1.45,label='Horizontal cut\n(68.3%)'),Line2D([0],[0],c='.65',ls='--',lw=.6,label='Scan boundary')]
 axs.flat[-1].legend(handles=handles,loc='center',frameon=False,handlelength=2.0,labelspacing=.8,borderaxespad=0)
 name='fig__intrinsic_subtracted_contours__eleven_m_'+('smoothed' if variant=='gaussian' else 'linear_P');save(fig,name);plt.close(fig)

def area_ratios():
 d=read('eleven_wedge_areas_domain_flags.csv');fig,axs=plt.subplots(1,3,figsize=(W,3.0));fig.subplots_adjust(left=.09,right=.99,bottom=.32,top=.88,wspace=.33)
 for i,f in enumerate(TARGETS):
  ax=axs[i]
  for method,c,ls,marker in [('linear_P','#24638b','-','s'),('linear_Q','#a8662c','--','o')]:
   s=d[(d.method==method)&np.isclose(d.target,f)&d.branch.str.startswith('m')].sort_values('m');ax.plot(s.m,s.area_over_horizontal,c=c,ls=ls,marker=marker,ms=3.8,label=method.replace('_','-'))
  ax.axhline(1,c='.25',ls=':',lw=1);clean(ax);ax.set_title(f'{f*100:.1f}%');ax.set_xlabel(r'$m$');ax.set_xlim(.25,1.74);ax.set_ylim(.35,1.60);ax.set_xticks([.3,1,1.7])
 axs[0].set_ylabel(r'$A_f(m)/A_f({\rm H})$');h,l=axs[0].get_legend_handles_labels();fig.legend(h,l,loc='lower center',bbox_to_anchor=(.54,.02),ncol=2,frameon=False)
 save(fig,'fig__intrinsic_subtracted_contours__eleven_m_areas');plt.close(fig)

def smoothing_areas():
 d=read('canonical_raster_areas.csv');d=d[d.grid==800];fig,axs=plt.subplots(2,3,figsize=(W,5.05),sharex=True);fig.subplots_adjust(left=.10,right=.99,bottom=.22,top=.91,wspace=.31,hspace=.21)
 for i,f in enumerate(TARGETS):
  a=d[np.isclose(d.target,f)]
  for variant,c,ls,marker,label in [('no_gaussian','#24638b','-','s','Unsmoothed'),('gaussian','#c76b20','--','o','Smoothed')]:
   s=a[(a.variant==variant)&a.branch.str.startswith('m')].sort_values('m');axs[0,i].plot(s.m,s.area*1e4,c=c,ls=ls,marker=marker,ms=3.4,label=label)
   ref=a[(a.variant==variant)&(a.branch=='horizontal_only')].area.iloc[0]*1e4;axs[0,i].axhline(ref,c=c,ls=':',lw=1.25)
  s=a[(a.variant=='gaussian')&a.branch.str.startswith('m')].sort_values('m');axs[1,i].plot(s.m,s.smooth_over_raw,c='#78448f',ls='-.',marker='D',ms=3.2);axs[1,i].axhline(1,c='.2',ls=':',lw=1)
  axs[0,i].set_title(f'{f*100:.1f}%');axs[1,i].set_xlabel(r'$m$')
  for ax in axs[:,i]:clean(ax);ax.set_xlim(.25,1.74);ax.set_xticks([.3,1,1.7])
  axs[0,i].set_ylim(bottom=0);axs[1,i].set_ylim(0,14)
 axs[0,0].set_ylabel(r'$A_f\ [10^{-4}]$');axs[1,0].set_ylabel(r'$A_{f,{\rm smooth}}/A_{f,{\rm raw}}$')
 h,l=axs[0,0].get_legend_handles_labels();h+=[Line2D([0],[0],c='.3',ls=':',label='Horizontal cut')];l+=['Horizontal cut'];fig.legend(h,l,loc='lower center',bbox_to_anchor=(.54,.015),ncol=3,frameon=False,columnspacing=1.1)
 save(fig,'fig__intrinsic_subtracted_contours__eleven_m_smoothing_areas');plt.close(fig)

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--only',default='all');args=ap.parse_args()
 funcs={'foreground':foreground,'redshifts':redshifts,'cosmologies':cosmologies,'slices':slices,'covariance':covariance,'evolution':evolution,'four_cases':four_cases,'eleven_raw':lambda:eleven_regions('no_gaussian'),'eleven_smooth':lambda:eleven_regions('gaussian'),'areas':area_ratios,'smoothing':smoothing_areas}
 for key,f in funcs.items():
  if args.only=='all' or key in args.only.split(','):f();print('Saved',key,flush=True)
 dest=O/'qa'/('figure_dimensions_'+args.only.replace(',','_')+'.json');dest.write_text(json.dumps(metadata,indent=2))
